package sistemaAutogestion;

//Agregar aquí nombres y números de estudiante de los integrantes del equipo

import dominio.Estacion;
import dominio.Usuario;
import dominio.Bicicleta;
import tads.ListaNodos;

public class Sistema implements IObligatorio {
    
    private ListaNodos<Estacion> estaciones;
    private ListaNodos<Usuario> usuarios;
    private ListaNodos<Bicicleta> deposito;
    private ListaNodos<Bicicleta> bicicletas;



    @Override
    public Retorno crearSistemaDeGestion() {
        estaciones = new ListaNodos();
        usuarios = new ListaNodos();
        deposito = new ListaNodos();
        bicicletas = new ListaNodos(); 
        return Retorno.ok();
    }

    @Override
    public Retorno registrarEstacion(String nombre, String barrio, int capacidad) {
        if (nombre == null || nombre.trim().isEmpty() || 
            barrio == null || barrio.trim().isEmpty()) 
        {
            return Retorno.error1();
        }
        if (capacidad <= 0) {
            return Retorno.error2();
        }
        if (estaciones.existeElemento(new Estacion(nombre, barrio, capacidad))) {
            return Retorno.error3();
        }
        estaciones.agregarOrd(new Estacion(nombre, barrio, capacidad));
        return Retorno.ok();

    }

    @Override
    public Retorno registrarUsuario(String cedula, String nombre) {
        if(cedula == null || cedula.trim().isEmpty() ||
           nombre == null || nombre.trim().isEmpty())
        {
            return Retorno.error1();
        }
        if(cedula.length() != 8){
            return Retorno.error2();
        }
        if(usuarios.existeElemento(new Usuario(cedula,nombre)) ){
            return Retorno.error3();
        }
        usuarios.agregarOrd(new Usuario(cedula,nombre));
        return Retorno.ok();
    }

    @Override
    public Retorno registrarBicicleta(String codigo, String tipo) {
        if(codigo == null || codigo.trim().isEmpty() ||
           tipo == null || tipo.trim().isEmpty())
        {
            return Retorno.error1();
        }else{
            Bicicleta bici = new Bicicleta(codigo,tipo);
       
            if(codigo.length() != 6){
                return Retorno.error2();
            }
            tipo = tipo.toUpperCase();
            if(!tipo.equals("URBANA") || !tipo.equals("MOUNTAIN") || !tipo.equals("ELECTRICA")){
                return Retorno.error3();
            }
            if(bicicletas.existeElemento(bici)){
                return Retorno.error4();
            }
            bici.setUbicacion("Deposito");
            bicicletas.agregarOrd(bici);
            deposito.agregarFinal(bici);
            return Retorno.ok();
            
        }
    }

    @Override
    public Retorno marcarEnMantenimiento(String codigo, String motivo) {
        //reever logica
        if (codigo == null || codigo.trim().isEmpty()
                || motivo == null || motivo.trim().isEmpty()) {
            return Retorno.error1();
        }
        Bicicleta bici;
        Bicicleta b = new Bicicleta(codigo, null);
        boolean existe = bicicletas.existeElemento(b);

        if (!existe) {
            return Retorno.error2();
        }
        
        bici = bicicletas.obtenerElemento(b).getDato();
        if (bici.isEnAlquiler()) {
            return Retorno.error3();
        }
        
        if (bici.isEnMantenimiento()) {
            return Retorno.error4();
        }

        if (!bici.getUbicacion().equals("DEPOSITO") || bici.getUbicacion() != null) {
            Estacion est = estaciones.obtenerElemento(new Estacion(bici.getUbicacion(), null, 0)).getDato();
            deposito.agregarOrd(bici);
            est.getBicicletas().borrarElemento(bici);
        }
        bici.setEnMantenimiento(true);
        bici.setMotivoMantenimiento(motivo);
        return Retorno.ok();
    }

    @Override
    public Retorno repararBicicleta(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()){
            return Retorno.error1();
        }
        Bicicleta b = new Bicicleta(codigo, null);
        boolean existe = bicicletas.existeElemento(b);

        if (!existe) {
            return Retorno.error2();
        }
        
        Bicicleta bici = bicicletas.obtenerElemento(b).getDato();
        if (!bici.isEnMantenimiento()) {
            return Retorno.error3();
        }
        
        bici.setEnMantenimiento(false);
        bici.setMotivoMantenimiento(null);
        return Retorno.ok();
    }

    @Override
    public Retorno eliminarEstacion(String nombre) {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno asignarBicicletaAEstacion(String codigo, String nombreEstacion) {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno alquilarBicicleta(String cedula, String nombreEstacion) {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno devolverBicicleta(String cedula, String nombreEstacionDestino) {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno deshacerUltimosRetiros(int n) {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno obtenerUsuario(String cedula) {
        if (cedula == null || cedula.trim().isEmpty()){
            return Retorno.error1();
        }
        
        if(cedula.length() != 8){
            return Retorno.error2();
        }
        Usuario u = new Usuario (cedula,null);
        if(!usuarios.existeElemento(u)){
            return Retorno.error3();
        }
        return Retorno.ok(usuarios.obtenerElemento(u).getDato().toString());
    }

    @Override
    public Retorno listarUsuarios() {
        return Retorno.ok(usuarios.listar());
    }

    @Override
    public Retorno listarBicisEnDeposito() {
        return Retorno.ok(deposito.listar());
    }

    @Override
    public Retorno informaciónMapa(String[][] mapa) {
        int contadorFila=0;
        int contadorColumna=0;
        int valorMaximo = 0;
        int contador = 0;
        String resultadoMaximo = "";
        String resultadoExistencia;
      
        for (int i = 0; i < mapa.length; i++) {
            for (int j = 0; j < mapa[i].length; j++) {
                if(!mapa[i][j].isEmpty()){
                    contadorFila++;
                }
                if(!mapa[j][i].isEmpty()){
                    contadorColumna++;
                    contador++;
                }
            }
            if(contadorColumna > valorMaximo && contadorFila < contadorColumna){
                valorMaximo = contadorColumna;
                resultadoMaximo = valorMaximo + "#" + "columna" + "|";
            }
            
            if (contadorFila > valorMaximo && contadorColumna < contadorFila){
                valorMaximo = contadorFila;
                resultadoMaximo = valorMaximo + "#" + "fila" + "|";
            }
            
            if (contadorFila > valorMaximo && contadorColumna == contadorFila){
                valorMaximo = contadorFila;
                resultadoMaximo = valorMaximo + "#" + "ambas" + "|";        
            }
            
            if (contadorColumna == 0 && contadorFila == 0){
                resultadoMaximo = valorMaximo + "#" + "ambas" + "|";        
            }
            
            contadorColumna = 0;
            contadorFila = 0;
            
            
        }
        
        return Retorno.ok(resultadoMaximo + resultadoExistencia);
    }

    @Override
    public Retorno listarBicicletasDeEstacion(String nombreEstacion) {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno estacionesConDisponibilidad(int n) {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno ocupacionPromedioXBarrio() {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno rankingTiposPorUso() {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno usuariosEnEspera(String nombreEstacion) {
        return Retorno.noImplementada();
    }

    @Override
    public Retorno usuarioMayor() {
        return Retorno.noImplementada();
    }

}
